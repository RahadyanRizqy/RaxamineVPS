@extends('master')

@section('content')
    <p>Sat Blade</p>
    {{-- @if(isset($result))
        <p> {{ $result['operating_system'] }} {{ $result['os_version'] }}</p>
    @endif --}}
@endsection